package br.edu.ifsuldeminas.mch.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import de.congrace.exp4j.Calculable;
import de.congrace.exp4j.ExpressionBuilder;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "ifsuldeminas.mch.calc";
    private Button buttonPorcento, buttonDivisao, buttonSubtracao, buttonMultiplicacao, buttonSoma, buttonPonto, buttonIgual, buttonApagar, buttonLimpar;
    private boolean haveDot = false;
    private TextView textViewUltimaExpressao;
    private TextView textViewResultado;
    private String expressao = "";
    private Button buttonZero, buttonUm, buttonDois, buttonTres, buttonQuatro, buttonCinco, buttonSeis, buttonSete, buttonOito, buttonNove;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewUltimaExpressao = findViewById(R.id.textViewUltimaExpressaoID);
        textViewResultado = findViewById(R.id.textViewResultadoID);

        textViewUltimaExpressao = findViewById(R.id.textViewUltimaExpressaoID);
        textViewResultado = findViewById(R.id.textViewResultadoID);

        buttonZero = findViewById(R.id.buttonZeroID);
        buttonUm = findViewById(R.id.buttonUmID);
        buttonDois = findViewById(R.id.buttonDoisID);
        buttonTres = findViewById(R.id.buttonTresID);
        buttonQuatro = findViewById(R.id.buttonQuatroID);
        buttonCinco = findViewById(R.id.buttonCincoID);
        buttonSeis = findViewById(R.id.buttonSeisID);
        buttonSete = findViewById(R.id.buttonSeteID);
        buttonOito = findViewById(R.id.buttonOitoID);
        buttonNove = findViewById(R.id.buttonNoveID);

        buttonPorcento = findViewById(R.id.buttonPorcentoID);
        buttonDivisao = findViewById(R.id.buttonDivisaoID);
        buttonSubtracao = findViewById(R.id.buttonSubtracaoID);
        buttonMultiplicacao = findViewById(R.id.buttonMultiplicacaoID);
        buttonSoma = findViewById(R.id.buttonSomaID);
        buttonPonto = findViewById(R.id.buttonPontoID);
        buttonApagar = findViewById(R.id.buttonDeleteID);
        buttonLimpar = findViewById(R.id.buttonResetID);
        buttonIgual = findViewById(R.id.buttonIgualID);

        buttonPorcento.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!expressao.equals("")) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);
                        if (ultimoChar == '-' && (expressao.charAt(expressao.length() - 2) == '*' || expressao.charAt(expressao.length() - 2) == '÷')) {
                            return;
                        }
                        if (haveOperator(ultimoChar)) {
                            expressao = expressao.substring(0, expressao.length() - 1);
                        }
                        showScreen(buttonPorcento);
                        haveDot = false;
                    } else {
                        if (!textViewResultado.getText().equals("0")) {
                            pickResultText(buttonPorcento);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonDivisao.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!expressao.equals("")) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);
                        if (ultimoChar == '-' && (expressao.charAt(expressao.length() - 2) == '*' || expressao.charAt(expressao.length() - 2) == '÷')) {
                            return;
                        }

                        if (haveOperator(ultimoChar)) {
                            expressao = expressao.substring(0, expressao.length() - 1);
                        }

                        showScreen(buttonDivisao);
                        haveDot = false;
                    } else {
                        if (!textViewResultado.getText().equals("0")) {
                            pickResultText(buttonDivisao);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonSubtracao.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    if (!expressao.equals("")) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);
                        if (negativeNumber(ultimoChar)) {
                            showScreen(buttonSubtracao);
                        } else {
                            if (ultimoChar == '-') {
                                expressao = expressao.substring(0, expressao.length() - 1);
                            } else {
                                if (haveOperator(ultimoChar)) {
                                    expressao = expressao.substring(0, expressao.length() - 1);
                                }
                            }
                            showScreen(buttonSubtracao);
                        }
                        haveDot = false;
                    } else {
                        if (!textViewResultado.getText().equals("0")) {
                            pickResultText(buttonSubtracao);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonMultiplicacao.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!expressao.equals("")) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);

                        if (ultimoChar == '-' && (expressao.charAt(expressao.length() - 2) == '*' || expressao.charAt(expressao.length() - 2) == '÷')) {
                            return;
                        }
                        if (haveOperator(ultimoChar)) {
                            expressao = expressao.substring(0, expressao.length() - 1);
                        }
                        showScreen(buttonMultiplicacao);
                        haveDot = false;
                    } else {
                        if (!textViewResultado.getText().equals("0")) {
                            pickResultText(buttonMultiplicacao);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonSoma.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!expressao.equals("")) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);
                        if (!(ultimoChar == '-' && (expressao.charAt(expressao.length() - 2) == '*' || expressao.charAt(expressao.length() - 2) == '÷'))) {
                            if (haveOperator(ultimoChar)) {
                                expressao = expressao.substring(0, expressao.length() - 1);
                            }
                            showScreen(buttonSoma);
                            haveDot = false;
                        }

                    } else {
                        if (!textViewResultado.getText().equals("0")) {
                            pickResultText(buttonSoma);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonPonto.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!expressao.equals("")) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);
                        if (haveOperator(ultimoChar)) {
                            return;
                        }
                    }

                    if (haveDot == false) {
                        if (expressao.equals("")) {
                            pickResultText(buttonPonto);
                        } else {
                            showScreen(buttonPonto);
                        }
                        haveDot = true;
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonApagar.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!expressao.isEmpty()) {
                        char ultimoChar = expressao.charAt(expressao.length() - 1);
                        if (ultimoChar == buttonPonto.getText().charAt(0)) {
                            haveDot = false;
                        }
                        expressao = expressao.substring(0, expressao.length() - 1);
                        textViewUltimaExpressao.setText(expressao);
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        }));

        buttonLimpar.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                expressao = "";
                textViewResultado.setText("0");
                haveDot = false;
                textViewUltimaExpressao.setText(expressao);
            }
        }));

        buttonIgual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calculable avaliadorExpressao = null;
                try {
                    expressao = expressao.replace("÷", "/");
                    char ultimoChar = expressao.charAt(expressao.length() - 1);
                    char penultimoChar = expressao.charAt(expressao.length() - 2);
                    if (haveOperator(ultimoChar)) {
                        expressao = expressao.substring(0, expressao.length() - 1);
                        if(haveOperator(penultimoChar)){
                            expressao = expressao.substring(0, expressao.length() - 1);
                        }
                    }
                    avaliadorExpressao = new ExpressionBuilder(expressao).build();

                    Double resultado = avaliadorExpressao.calculate();


                    expressao = "";
                    textViewUltimaExpressao.setText(expressao);
                    textViewResultado.setText(String.format("%.2f", resultado));
                } catch (
                        Exception e) {
                    Log.d(TAG, e.getMessage());
                }
            }
        });

        buttonZero.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonZero);
            }
        }));

        buttonUm.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonUm);
            }
        }));

        buttonDois.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonDois);
            }
        }));

        buttonTres.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonTres);
            }
        }));

        buttonQuatro.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonQuatro);
            }
        }));

        buttonCinco.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonCinco);
            }
        }));

        buttonSeis.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonSeis);
            }
        }));

        buttonSete.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonSete);
            }
        }));

        buttonOito.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonOito);
            }
        }));

        buttonNove.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScreen(buttonNove);
            }
        }));
    }

    public void showScreen(Button button) {
        expressao += button.getText();
        textViewUltimaExpressao.setText(expressao);
    }

    public boolean negativeNumber(char ultimoChar) {
        if (ultimoChar == buttonDivisao.getText().charAt(0) || ultimoChar == buttonMultiplicacao.getText().charAt(0) || expressao.isEmpty()) {
            return true;
        }
        return false;
    }

    public boolean secondOperator(char penultimoChar) {
        if (expressao.charAt(penultimoChar) == buttonDivisao.getText().charAt(0) ||
                expressao.charAt(penultimoChar) == buttonMultiplicacao.getText().charAt(0))
            return true;
        return false;
    }

    public boolean haveOperator(char ultimoChar) {
        if ((ultimoChar == buttonDivisao.getText().charAt(0) ||
                ultimoChar == buttonMultiplicacao.getText().charAt(0) ||
                ultimoChar == buttonSubtracao.getText().charAt(0) ||
                ultimoChar == buttonSoma.getText().charAt(0) ||
                ultimoChar == buttonPorcento.getText().charAt(0) ||
                ultimoChar == buttonPorcento.getText().charAt(0)))
            return true;

        return false;
    }

    public void pickResultText(Button button) {
        expressao += textViewResultado.getText();
        expressao += button.getText();
        textViewUltimaExpressao.setText(expressao);
        textViewResultado.setText("");
    }
}